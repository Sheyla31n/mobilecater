package com.azhar.catering.history;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import com.azhar.catering.R;
import com.azhar.catering.database.DatabaseModel;
import com.azhar.catering.utils.FunctionHelper;

import java.text.NumberFormat;
import java.util.List;
import java.util.Locale;

public class HistoryAdapter extends RecyclerView.Adapter<HistoryAdapter.ViewHolder> {

    List<DatabaseModel> modelDatabase;
    Context mContext;

    public HistoryAdapter(Context context, List<DatabaseModel> modelInputList) {
        this.mContext = context;
        this.modelDatabase = modelInputList;
    }

    // Method to update the adapter data
    public void setDataAdapter(List<DatabaseModel> items) {
        modelDatabase.clear();
        modelDatabase.addAll(items);
        notifyDataSetChanged();
    }

    @Override
    public HistoryAdapter.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.list_item_riwayat, parent, false);
        return new HistoryAdapter.ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(HistoryAdapter.ViewHolder holder, int position) {
        final DatabaseModel data = modelDatabase.get(position);

        // Set tvNama to reflect Pesanan 1, Pesanan 2, etc.
        holder.tvNama.setText("Pesanan " + (position + 1)); // Position + 1 for 1-based index

        // Set tvPrice to show totalharga
        holder.tvPrice.setText("Rp. " + formatRupiah(data.getHarga())); // Assuming getHarga() returns the total price

        // Handle feedback button click
        holder.btnFeedback.setOnClickListener(v -> {
            // Pass order details, total price, and shipping cost to FeedbackActivity
            Intent intent = new Intent(mContext, FeedbackActivity.class);

            intent.putExtra("DETAIL_PESANAN", data.getNama_menu()); // Assuming getDetailPesanan() contains the order details
            intent.putExtra("TOTAL_HARGA", data.getHarga()); // Assuming getHarga() returns the total price
            intent.putExtra("ONGKIR", data.getOngkir()); // Assuming getOngkir() returns the shipping cost
            mContext.startActivity(intent);
        });
    }

    // Format harga menjadi format Rupiah
    private String formatRupiah(double amount) {
        NumberFormat format = NumberFormat.getCurrencyInstance(new Locale("id", "ID"));
        return format.format(amount);
    }

    @Override
    public int getItemCount() {
        return modelDatabase.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        public TextView tvNama, tvPrice;
        public Button btnFeedback; // Declare button inside ViewHolder

        public ViewHolder(View itemView) {
            super(itemView);
            tvNama = itemView.findViewById(R.id.tvNama);
            tvPrice = itemView.findViewById(R.id.tvPrice);
            btnFeedback = itemView.findViewById(R.id.btnFeedback); // Initialize the button here
        }
    }

    // Method to remove item on swipe
    public void setSwipeRemove(int position) {
        modelDatabase.remove(position);
        notifyItemRemoved(position);
    }

    // Method to restore item after canceling swipe
    public void restoreItem(DatabaseModel databaseModel, int position) {
        modelDatabase.add(position, databaseModel);
        notifyItemInserted(position);
    }

    public List<DatabaseModel> getData() {
        return modelDatabase;
    }
}
