package com.azhar.catering.order;

import android.app.Application;

import androidx.annotation.NonNull;
import androidx.lifecycle.AndroidViewModel;
import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;

import com.azhar.catering.database.DatabaseModel;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;

/**
 * OrderViewModel for Firebase Realtime Database integration
 */
public class OrderViewModel extends AndroidViewModel {

    private final DatabaseReference databaseReference;
    private final MutableLiveData<List<DatabaseModel>> modelDatabase = new MutableLiveData<>();

    public OrderViewModel(@NonNull Application application) {
        super(application);

        // Reference to Firebase Realtime Database
        databaseReference = FirebaseDatabase.getInstance().getReference("orders");
    }

    /**
     * Fetch data from Firebase Realtime Database
     */
    public LiveData<List<DatabaseModel>> getDataIdUser() {
        databaseReference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                List<DatabaseModel> databaseModels = new ArrayList<>();
                for (DataSnapshot data : snapshot.getChildren()) {
                    DatabaseModel databaseModel = data.getValue(DatabaseModel.class);
                    if (databaseModel != null) {
                        databaseModels.add(databaseModel);
                    }
                }
                modelDatabase.setValue(databaseModels);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                // Handle database error
            }
        });

        return modelDatabase;
    }

    /**
     * Add data to Firebase Realtime Database
     */
    public void addDataOrder(final String strMenu, final int intHarga, final String strAlamat, final int intTotal, final int intOngkir, final String strCatatan) {
        DatabaseModel databaseModel = new DatabaseModel();
        databaseModel.nama_menu = strMenu;
        databaseModel.alamat = strAlamat;
        databaseModel.harga = intHarga;
        databaseModel.ongkir = intOngkir;
        databaseModel.total = intTotal;
        databaseModel.catatan = strCatatan;


        // Push new order data to Firebase
        databaseReference.push().setValue(databaseModel)
                .addOnCompleteListener(task -> {
                    if (task.isSuccessful()) {
                        // Success message
                    } else {
                        // Error handling
                    }
                });
    }
}
