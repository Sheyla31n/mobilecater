package com.azhar.catering.database;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class DatabaseClient {

    private static DatabaseClient mInstance;
    private DatabaseReference mDatabase;

    // Singleton instance untuk akses Firebase Database
    private DatabaseClient() {
        // Menyesuaikan reference ke root database di Firebase
        mDatabase = FirebaseDatabase.getInstance().getReference();
    }

    // Mengambil instance dari DatabaseClient
    public static synchronized DatabaseClient getInstance() {
        if (mInstance == null) {
            mInstance = new DatabaseClient();
        }
        return mInstance;
    }

    // Mendapatkan reference ke root database
    public DatabaseReference getDatabase() {
        return mDatabase;
    }

    // Mendapatkan reference spesifik berdasarkan key
    public DatabaseReference getEmailReference() {
        return mDatabase.child("nohp");
    }

    public DatabaseReference getHargaReference() {
        return mDatabase.child("harga");
    }

    public DatabaseReference getItemsReference() {
        return mDatabase.child("items");
    }

    public DatabaseReference getNamaMenuReference() {
        return mDatabase.child("nama_menu");
    }

    public DatabaseReference getPasswordReference() {
        return mDatabase.child("password");
    }

    public DatabaseReference getUsernameReference() {
        return mDatabase.child("username");
    }
}
