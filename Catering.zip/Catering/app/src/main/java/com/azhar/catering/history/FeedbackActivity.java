package com.azhar.catering.history;

import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.lifecycle.ViewModelProvider;
import androidx.lifecycle.ViewModelProviders;
import androidx.recyclerview.widget.ItemTouchHelper;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.azhar.catering.R;
import com.azhar.catering.database.DatabaseModel;
import com.azhar.catering.main.MainActivity;
import com.azhar.catering.order.MapActivity;
import com.azhar.catering.order.OrderViewModel;

import java.text.NumberFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class FeedbackActivity extends AppCompatActivity {

    private LinearLayout layoutPesanan;
    private TextView tvTotalHarga, tvOngkir, tvCatatan;
    private Button btnOk, btnCancel;
    private int ongkir;
    private int totalHarga;
    private String detailPesanan;
    private int position;
    Toolbar toolbar;// Position to update the correct order
    FeedbackViewModel feedbackViewModel;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.list_feedback);

        // Inisialisasi ViewModel
        feedbackViewModel = new ViewModelProvider(this).get(FeedbackViewModel.class);

        // Menghubungkan Views
        tvTotalHarga = findViewById(R.id.tvTotalHarga);
        layoutPesanan = findViewById(R.id.layoutPesanan);
        btnOk = findViewById(R.id.btnOkk);
        tvOngkir = findViewById(R.id.tvOngkir);
        btnCancel = findViewById(R.id.btnBatal);
        tvCatatan = findViewById(R.id.tvFeedback);

        // Mendapatkan data dari Intent
        Intent intent = getIntent();
        detailPesanan = intent.getStringExtra("DETAIL_PESANAN");
        totalHarga = intent.getIntExtra("TOTAL_HARGA", 0);
        ongkir = intent.getIntExtra("ONGKIR", 0);

        // Display total price with Rupiah format
        tvTotalHarga.setText("Total: " + formatRupiah(totalHarga + ongkir));
        // Display order details in layoutPesanan
        displayOrderDetails(detailPesanan);

        btnOk.setOnClickListener(v -> {
            String strIsi = tvCatatan.getText().toString(); // Get feedback notes

            // Update the feedback data for the selected order
            feedbackViewModel.addDataFeedback( strIsi); // Assuming position is the index of the selected order

            // Return to HistoryOrderActivity
            Intent backIntent = new Intent(FeedbackActivity.this, HistoryOrderActivity.class);
            startActivity(backIntent);
        });

        btnCancel.setOnClickListener(v -> {
            // Cancel the feedback and go back to HistoryOrderActivity
            Intent cancelIntent = new Intent(FeedbackActivity.this, HistoryOrderActivity.class);
            startActivity(cancelIntent);
        });

        setToolbar();
    }

    // Setup toolbar
    private void setToolbar() {
        toolbar = findViewById(R.id.toolbar);
        toolbar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(FeedbackActivity.this, MainActivity.class);
                startActivity(intent);
            }
        });
    }

    // Format price as Rupiah
    private String formatRupiah(double amount) {
        NumberFormat format = NumberFormat.getCurrencyInstance(new Locale("id", "ID"));
        return format.format(amount);
    }

    // Display order details in layoutPesanan
    private void displayOrderDetails(String detailPesanan) {
        if (detailPesanan == null || detailPesanan.isEmpty()) {
            TextView tvKosong = new TextView(this);
            tvKosong.setText("Belum ada pesanan");
            layoutPesanan.addView(tvKosong);
            return;
        }

        String[] items = detailPesanan.split("\n");

        for (String item : items) {
            if (!item.isEmpty()) {
                // Create a new LinearLayout for each item in the order
                LinearLayout itemLayout = new LinearLayout(this);
                itemLayout.setLayoutParams(new LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.MATCH_PARENT,
                        LinearLayout.LayoutParams.WRAP_CONTENT
                ));
                itemLayout.setOrientation(LinearLayout.HORIZONTAL);

                // Create TextView for package name
                TextView tvNamaPaket = new TextView(this);
                tvNamaPaket.setLayoutParams(new LinearLayout.LayoutParams(
                        0,
                        LinearLayout.LayoutParams.WRAP_CONTENT,
                        0.6f
                ));
                tvNamaPaket.setText(item.split("-")[0].trim());

                // Create TextView for price
                TextView tvHarga = new TextView(this);
                tvHarga.setLayoutParams(new LinearLayout.LayoutParams(
                        0,
                        LinearLayout.LayoutParams.WRAP_CONTENT,
                        0.4f
                ));
                tvHarga.setGravity(android.view.Gravity.END);
                tvHarga.setText(item.split("-")[1].trim());

                // Add item to the layout
                itemLayout.addView(tvNamaPaket);
                itemLayout.addView(tvHarga);
                layoutPesanan.addView(itemLayout);
            }
        }
    }
}



