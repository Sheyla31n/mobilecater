package com.azhar.catering.login;

import android.app.Application;

import androidx.annotation.NonNull;
import androidx.lifecycle.AndroidViewModel;
import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;

import com.azhar.catering.database.DatabaseModel;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class LoginViewModel extends AndroidViewModel {

    private MutableLiveData<DatabaseModel> loggedInUser; // Data pengguna yang berhasil login
    private FirebaseDatabase firebaseDatabase;

    // Constructor untuk inisialisasi Firebase Database
    public LoginViewModel(@NonNull Application application) {
        super(application);
        firebaseDatabase = FirebaseDatabase.getInstance();
        loggedInUser = new MutableLiveData<>();
    }

    // Method untuk mengambil data pengguna berdasarkan username dan password
    public LiveData<DatabaseModel> getDataUser(String username, String password) {
        firebaseDatabase.getReference("users") // Akses node "users"
                .addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                        boolean isFound = false; // Flag untuk mengecek apakah data ditemukan
                        // Loop melalui semua children di node "users"
                        for (DataSnapshot userSnapshot : dataSnapshot.getChildren()) {
                            // Ambil data pengguna sebagai DatabaseModel
                            DatabaseModel users = userSnapshot.getValue(DatabaseModel.class);
                            if (users != null
                                    && username.equals(users.getUsername()) // Validasi username
                                    && password.equals(users.getPassword())) { // Validasi password
                                loggedInUser.setValue(users); // Simpan data pengguna yang cocok
                                isFound = true; // Set flag sebagai ditemukan
                                break; // Hentikan loop jika data cocok ditemukan
                            }
                        }

                        // Jika tidak ditemukan, set LiveData sebagai null
                        if (!isFound) {
                            loggedInUser.setValue(null);
                        }
                    }
                    @Override
                    public void onCancelled(@NonNull DatabaseError databaseError) {
                        loggedInUser.setValue(null); // Set null jika terjadi error
                    }
                });
        return loggedInUser;
    }
}
