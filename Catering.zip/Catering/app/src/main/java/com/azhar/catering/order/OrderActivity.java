package com.azhar.catering.order;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Paint;
import android.os.Build;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.lifecycle.ViewModelProvider;
import androidx.lifecycle.ViewModelProviders;

import com.azhar.catering.R;
import com.azhar.catering.utils.FunctionHelper;
import com.google.android.material.button.MaterialButton;

public class OrderActivity extends AppCompatActivity {

    public static final String DATA_TITLE = "TITLE";
    String strTitle;
    int paket1 = 21000, paket2 = 34000, paket3 = 23700, paket4 = 22500, paket5 = 16500, paket6 = 26000;
    int itemCount1 = 0, itemCount2 = 0, itemCount3 = 0, itemCount4 = 0, itemCount5 = 0, itemCount6 = 0;
    int countP1, countP2, countP3, countP4, countP5, countP6, totalItems, totalPrice;
    ImageView imageAdd1, imageAdd2, imageAdd3, imageAdd4, imageAdd5, imageAdd6,
            imageMinus1, imageMinus2, imageMinus3, imageMinus4, imageMinus5, imageMinus6;
    Toolbar toolbar;
    TextView tvPaket1, tvPaket2, tvPaket3, tvPaket4, tvPaket5, tvPaket6, tvJumlahPorsi, tvTotalPrice, tvMenu1, tvMenu2, tvMenu3, tvMenu4, tvMenu5, tvMenu6;
    MaterialButton btnCheckout;
    OrderViewModel orderViewModel;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_order);

        toolbar = findViewById(R.id.toolbar);
        tvPaket1 = findViewById(R.id.tvPaket1);
        tvPaket2 = findViewById(R.id.tvPaket2);
        tvPaket3 = findViewById(R.id.tvPaket3);
        tvPaket4 = findViewById(R.id.tvPaket4);
        tvPaket5 = findViewById(R.id.tvPaket5);
        tvPaket6 = findViewById(R.id.tvPaket6);
        tvJumlahPorsi = findViewById(R.id.tvJumlahPorsi);
        tvTotalPrice = findViewById(R.id.tvTotalPrice);
        imageAdd1 = findViewById(R.id.imageAdd1);
        imageAdd2 = findViewById(R.id.imageAdd2);
        imageAdd3 = findViewById(R.id.imageAdd3);
        imageAdd4 = findViewById(R.id.imageAdd4);
        imageAdd5 = findViewById(R.id.imageAdd5);
        imageAdd6 = findViewById(R.id.imageAdd6);
        imageMinus1 = findViewById(R.id.imageMinus1);
        imageMinus2 = findViewById(R.id.imageMinus2);
        imageMinus3 = findViewById(R.id.imageMinus3);
        imageMinus4 = findViewById(R.id.imageMinus4);
        imageMinus5 = findViewById(R.id.imageMinus5);
        imageMinus6 = findViewById(R.id.imageMinus6);
        btnCheckout = findViewById(R.id.btnCheckout);
        tvMenu1 = findViewById(R.id.tvMenu1);
        tvMenu2 = findViewById(R.id.tvMenu2);
        tvMenu3 = findViewById(R.id.tvMenu3);
        tvMenu4 = findViewById(R.id.tvMenu4);
        tvMenu5 = findViewById(R.id.tvMenu5);
        tvMenu6 = findViewById(R.id.tvMenu6);


        setInitLayout();
        setToolbar();
        setPaket1();
        setPaket2();
        setPaket3();
        setPaket4();
        setPaket5();
        setPaket6();
        setInputData();
    }

    // Setup toolbar
    private void setToolbar() {
        toolbar = findViewById(R.id.toolbar);

        setSupportActionBar(toolbar);
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setDisplayShowTitleEnabled(false);
        }
    }


    private void setInitLayout() {

        orderViewModel = new ViewModelProvider(this).get(OrderViewModel.class);
    }

    private void setPaket1() {
        imageAdd1.setOnClickListener(v -> {
            itemCount1 = itemCount1 + 1;
            tvPaket1.setText(String.valueOf(itemCount1));
            countP1 = paket1 * itemCount1;
            setTotalPrice();
        });

        imageMinus1.setOnClickListener(v -> {
            if (itemCount1 > 0) {
                itemCount1 = itemCount1 - 1;
                tvPaket1.setText(String.valueOf(itemCount1));
            }
            countP2 = paket2 * itemCount1;
            setTotalPrice();
        });
    }

    private void setPaket2() {
        imageAdd2.setOnClickListener(v -> {
            itemCount2 = itemCount2 + 1;
            tvPaket2.setText(String.valueOf(itemCount2));
            countP2 = paket2 * itemCount2;
            setTotalPrice();
        });

        imageMinus2.setOnClickListener(v -> {
            if (itemCount2 > 0) {
                itemCount2 = itemCount2 - 1;
                tvPaket2.setText(String.valueOf(itemCount2));
            }
            countP2 = paket2 * itemCount2;
            setTotalPrice();
        });
    }

    private void setPaket3() {
        imageAdd3.setOnClickListener(v -> {
            itemCount3 = itemCount3 + 1;
            tvPaket3.setText(String.valueOf(itemCount3));
            countP3 = paket3 * itemCount3;
            setTotalPrice();
        });

        imageMinus3.setOnClickListener(v -> {
            if (itemCount3 > 0) {
                itemCount3 = itemCount3 - 1;
                tvPaket3.setText(String.valueOf(itemCount3));
            }
            countP3 = paket3 * itemCount3;
            setTotalPrice();
        });
    }

    private void setPaket4() {
        imageAdd4.setOnClickListener(v -> {
            itemCount4 = itemCount4 + 1;
            tvPaket4.setText(String.valueOf(itemCount4));
            countP4 = paket4 * itemCount4;
            setTotalPrice();
        });

        imageMinus4.setOnClickListener(v -> {
            if (itemCount4 > 0) {
                itemCount4 = itemCount4 - 1;
                tvPaket4.setText(String.valueOf(itemCount4));
            }
            countP4 = paket4 * itemCount4;
            setTotalPrice();
        });
    }

    private void setPaket5() {
        imageAdd5.setOnClickListener(v -> {
            itemCount5 = itemCount5 + 1;
            tvPaket5.setText(String.valueOf(itemCount5));
            countP5 = paket5 * itemCount5;
            setTotalPrice();
        });

        imageMinus5.setOnClickListener(v -> {
            if (itemCount5 > 0) {
                itemCount5 = itemCount5 - 1;
                tvPaket5.setText(String.valueOf(itemCount5));
            }
            countP5 = paket5 * itemCount5;
            setTotalPrice();
        });
    }

    private void setPaket6() {
        imageAdd6.setOnClickListener(v -> {
            itemCount6 = itemCount6 + 1;
            tvPaket6.setText(String.valueOf(itemCount6));
            countP6 = paket6 * itemCount6;
            setTotalPrice();
        });

        imageMinus6.setOnClickListener(v -> {
            if (itemCount6 > 0) {
                itemCount6 = itemCount6 - 1;
                tvPaket6.setText(String.valueOf(itemCount6));
            }
            countP6 = paket6 * itemCount6;
            setTotalPrice();
        });
    }


    private void setTotalPrice() {
        totalItems = itemCount1 + itemCount2 + itemCount3 + itemCount4 + itemCount5 + itemCount6;
        totalPrice = countP1 + countP2 + countP3 + countP4 + countP5 + countP6;


        tvJumlahPorsi.setText(totalItems + " items");
        tvTotalPrice.setText(FunctionHelper.rupiahFormat(totalPrice));
    }

    private void setInputData() {
        btnCheckout.setOnClickListener(v -> {
            if (totalItems == 0 || totalPrice == 0) {
                Toast.makeText(OrderActivity.this, "Ups, pilih menu makanan dulu!",
                        Toast.LENGTH_SHORT).show();
            } else {
                // Buat Intent untuk pindah ke DetailOrder.java
                Intent intent = new Intent(OrderActivity.this, DetailOrder.class);

                // Kirim data pesanan dalam bentuk String
                String detailPesanan = generateDetailPesanan();
                intent.putExtra("DETAIL_PESANAN", detailPesanan);
                intent.putExtra("TOTAL_HARGA", totalPrice);

                startActivity(intent);  // Pindah ke DetailOrder.java
            }
        });
    }

    private String generateDetailPesanan() {
        StringBuilder detail = new StringBuilder();

        if (itemCount1 > 0) {
            detail.append(itemCount1).append("x Paket 1 - ").append(FunctionHelper.rupiahFormat(countP1)).append("\n");
        }
        if (itemCount2 > 0) {
            detail.append(itemCount2).append("x Paket 2 - ").append(FunctionHelper.rupiahFormat(countP2)).append("\n");
        }
        if (itemCount3 > 0) {
            detail.append(itemCount3).append("x Paket 3 - ").append(FunctionHelper.rupiahFormat(countP3)).append("\n");
        }
        if (itemCount4 > 0) {
            detail.append(itemCount4).append("x Paket 4 - ").append(FunctionHelper.rupiahFormat(countP4)).append("\n");
        }
        if (itemCount5 > 0) {
            detail.append(itemCount5).append("x Paket 5 - ").append(FunctionHelper.rupiahFormat(countP5)).append("\n");
        }
        if (itemCount6 > 0) {
            detail.append(itemCount6).append("x Paket 6 - ").append(FunctionHelper.rupiahFormat(countP6)).append("\n");
        }

        return detail.toString();
    }


    // ... (Metode setStatusbar dan setWindowFlag tetap sama) ...

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            finish();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }
}
