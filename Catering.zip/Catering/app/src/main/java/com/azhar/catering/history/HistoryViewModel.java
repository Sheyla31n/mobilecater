package com.azhar.catering.history;

import android.app.Application;

import androidx.annotation.NonNull;
import androidx.lifecycle.AndroidViewModel;
import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;

import com.azhar.catering.database.DatabaseModel;
import com.azhar.catering.database.DatabaseRepository;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;

public class HistoryViewModel extends AndroidViewModel {

    private MutableLiveData<List<DatabaseModel>> modelDatabase;
    private DatabaseReference databaseReference;
    private DatabaseRepository databaseRepository;

    // Constructor for initializing Firebase Database reference
    public HistoryViewModel(@NonNull Application application) {
        super(application);
        databaseReference = FirebaseDatabase.getInstance().getReference("orders");
        modelDatabase = new MutableLiveData<>();
        fetchDataFromFirebase();

        databaseRepository = new DatabaseRepository(application);  // Initialize the repository
    }

    // Method to update the feedback for a specific order (by position or ID)
    public void updateOrderFeedback(int position, String feedback) {
        // Call the updateFeedback method from DatabaseRepository to update the feedback
        databaseRepository.updateFeedback(position, feedback); // Pass the position or ID and feedback
    }

    // Method to fetch data from Firebase Realtime Database
    private void fetchDataFromFirebase() {
        databaseReference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                List<DatabaseModel> dataList = new ArrayList<>();
                for (DataSnapshot snapshot : dataSnapshot.getChildren()) {
                    DatabaseModel data = snapshot.getValue(DatabaseModel.class);
                    if (data != null) {
                        dataList.add(data);
                    }
                }
                modelDatabase.setValue(dataList);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                modelDatabase.setValue(null); // Handle error
            }
        });
    }

    // Method for retrieving data from the Firebase database to display in the RecyclerView
    public LiveData<List<DatabaseModel>> getDataList() {
        return modelDatabase;
    }

    // Method for deleting data by ID in real-time (using Firebase Realtime Database)
    public void deleteDataById(final String uid) {
        databaseReference.child(uid).removeValue().addOnCompleteListener(task -> {
            if (task.isSuccessful()) {
                fetchDataFromFirebase(); // Refresh the data list after deletion
            }
        });
    }

    // Method to add feedback data to the Firebase database
    public void addDataFeedback(final String strIsi) {
        DatabaseModel databaseModel = new DatabaseModel();
        databaseModel.isi = strIsi;

        // Push new order data to Firebase
        databaseReference.push().setValue(databaseModel)
                .addOnCompleteListener(task -> {
                    if (task.isSuccessful()) {
                        // Success message
                    } else {
                        // Error handling
                    }
                });
    }
}
