package com.azhar.catering.database;

import android.content.Context;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class DatabaseRepository {

    private DatabaseReference databaseReference;

    public DatabaseRepository(Context context) {
        databaseReference = FirebaseDatabase.getInstance().getReference("orders");
    }

    // Method to update feedback for a specific order
    public void updateFeedback(int position, String feedback) {
        // Assuming you have an ID or some unique identifier for each order
        // You will need to retrieve the order by its ID or position and update the feedback
        // Here's an example where we use "orders" as a reference:

        String orderId = "order_" + position; // or retrieve order ID differently
        databaseReference.child(orderId).child("feedback").setValue(feedback);
    }

    // Other methods for interacting with the database (e.g., add, delete, etc.)
}
