package com.azhar.catering.register;

import android.os.Bundle;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.ViewModelProvider;

import com.azhar.catering.R;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.textfield.TextInputEditText;

public class RegisterActivity extends AppCompatActivity {

    TextInputEditText inputNohp, inputUser, inputPassword;
    MaterialButton btnRegister;
    String strNohp, strUser, strPassword;
    RegisterViewModel registerViewModel;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        setInitLayout();
        setInputData();
    }

    private void setInitLayout() {
        inputNohp = findViewById(R.id.inputNohp); // Mengambil ID untuk nomor HP
        inputUser = findViewById(R.id.inputUser); // Mengambil ID untuk username
        inputPassword = findViewById(R.id.inputPassword); // Mengambil ID untuk password
        btnRegister = findViewById(R.id.btnRegister);

        // Inisialisasi ViewModel
        registerViewModel = new ViewModelProvider(this).get(RegisterViewModel.class);
    }

    private void setInputData() {
        btnRegister.setOnClickListener(v -> {
            // Mengambil input dari pengguna
            strNohp = inputNohp.getText().toString().trim();
            strUser = inputUser.getText().toString().trim();
            strPassword = inputPassword.getText().toString().trim();

            // Validasi input
            if (strNohp.isEmpty() || strUser.isEmpty() || strPassword.isEmpty()) {
                Toast.makeText(RegisterActivity.this, "Ups, semua form harus diisi!",
                        Toast.LENGTH_SHORT).show();
            } else {
                // Memasukkan data ke Firebase
                registerViewModel.addDataRegister(strUser, strNohp, strPassword).observe(this, isSuccess -> {
                    if (isSuccess != null && isSuccess) {
                        Toast.makeText(RegisterActivity.this,
                                "Registrasi berhasil! Silahkan login.",
                                Toast.LENGTH_SHORT).show();
                        finish(); // Menutup aktivitas setelah berhasil
                    } else {
                        Toast.makeText(RegisterActivity.this,
                                "Ups, terjadi kesalahan saat registrasi!",
                                Toast.LENGTH_SHORT).show();
                    }
                });
            }
        });
    }
}
