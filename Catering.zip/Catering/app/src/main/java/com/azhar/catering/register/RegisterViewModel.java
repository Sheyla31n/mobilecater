package com.azhar.catering.register;

import android.app.Application;
import androidx.annotation.NonNull;
import androidx.lifecycle.AndroidViewModel;
import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.HashMap;
import java.util.Map;

public class RegisterViewModel extends AndroidViewModel {

    private final DatabaseReference databaseReference;

    // Constructor untuk inisialisasi Firebase Database reference
    public RegisterViewModel(@NonNull Application application) {
        super(application);

        // Mengambil reference ke node "users"
        databaseReference = FirebaseDatabase.getInstance().getReference("users");
    }

    // Method untuk menambahkan data registrasi ke Firebase
    public LiveData<Boolean> addDataRegister(final String strUsername, final String strNohp, final String strPassword) {
        MutableLiveData<Boolean> isSuccess = new MutableLiveData<>();
        String userId = databaseReference.push().getKey(); // Generate unique ID untuk setiap user

        if (userId != null) {
            // Membuat map untuk menyimpan data user
            Map<String, Object> userData = new HashMap<>();
            userData.put("username", strUsername);
            userData.put("nohp", strNohp);
            userData.put("password", strPassword);

            // Menyimpan data ke node "users"
            databaseReference.child(userId).setValue(userData).addOnCompleteListener(task -> {
                isSuccess.setValue(task.isSuccessful()); // Mengembalikan status keberhasilan
            });
        } else {
            isSuccess.setValue(false); // Gagal jika userId tidak bisa dibuat
        }

        return isSuccess;
    }
}
