package com.azhar.catering.login;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.ViewModelProvider;

import com.azhar.catering.R;
import com.azhar.catering.database.DatabaseModel;
import com.azhar.catering.main.MainActivity;
import com.azhar.catering.register.RegisterActivity;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.textfield.TextInputEditText;

public class LoginActivity extends AppCompatActivity {

    private TextInputEditText inputUser, inputPassword;
    private MaterialButton btnLogin, btnRegister;
    private LoginViewModel loginViewModel;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        // Inisialisasi layout dan ViewModel
        setInitLayout();
        setupViewModel();
        setupListeners();

        // Mengecek apakah sudah ada sesi login sebelumnya
        checkLoggedInStatus();
    }

    private void setInitLayout() {
        inputUser = findViewById(R.id.inputUser);
        inputPassword = findViewById(R.id.inputPassword);
        btnLogin = findViewById(R.id.btnLogin);
        btnRegister = findViewById(R.id.btnRegister);
    }

    private void setupViewModel() {
        // Gunakan ViewModelProvider untuk mendapatkan LoginViewModel
        loginViewModel = new ViewModelProvider(this).get(LoginViewModel.class);
    }

    private void setupListeners() {
        // Navigasi ke RegisterActivity saat tombol Register ditekan
        btnRegister.setOnClickListener(v -> {
            Intent intent = new Intent(LoginActivity.this, RegisterActivity.class);
            startActivity(intent);
        });

        // Login saat tombol Login ditekan
        btnLogin.setOnClickListener(v -> {
            String strUsername = inputUser.getText().toString().trim();
            String strPassword = inputPassword.getText().toString().trim();

            // Validasi input
            if (strUsername.isEmpty() || strPassword.isEmpty()) {
                Toast.makeText(LoginActivity.this, "Ups, Form harus diisi semua!", Toast.LENGTH_SHORT).show();
                return;
            }

            // Observasi data dari ViewModel
            loginViewModel.getDataUser(strUsername, strPassword).observe(this, user -> {
                if (user != null) {
                    // Login berhasil
                    handleSuccessfulLogin(user);
                } else {
                    // Login gagal
                    Toast.makeText(LoginActivity.this, "Ups, Username atau Password Anda salah!", Toast.LENGTH_SHORT).show();
                    Log.e("LoginActivity", "Login gagal: data tidak ditemukan");
                }
            });
        });
    }

    private void handleSuccessfulLogin(DatabaseModel user) {
        // Menyimpan data pengguna ke SharedPreferences
        SharedPreferences prefs = getSharedPreferences("MyAppPrefs", MODE_PRIVATE);
        SharedPreferences.Editor editor = prefs.edit();
        editor.putBoolean("isLoggedIn", true);  // Menandai pengguna sudah login
        editor.putString("username", user.getUsername());  // Menyimpan username
        editor.putString("nohp", user.getNohp());  // Menyimpan nomor handphone
        editor.apply();  // Menyimpan perubahan

        Log.d("LoginActivity", "Login berhasil: " + user.getUsername());

        // Navigasi ke MainActivity
        Intent intent = new Intent(LoginActivity.this, MainActivity.class);
        startActivity(intent);
        finish(); // Menutup LoginActivity
    }

    // Mengecek status login saat aplikasi dibuka
    private void checkLoggedInStatus() {
        SharedPreferences prefs = getSharedPreferences("MyAppPrefs", MODE_PRIVATE);
        boolean isLoggedIn = prefs.getBoolean("isLoggedIn", false);  // Cek apakah pengguna sudah login

        if (isLoggedIn) {
            // Jika sudah login, langsung menuju ke MainActivity
            Intent intent = new Intent(LoginActivity.this, MainActivity.class);
            startActivity(intent);
            finish(); // Menutup LoginActivity
        }
    }
}
