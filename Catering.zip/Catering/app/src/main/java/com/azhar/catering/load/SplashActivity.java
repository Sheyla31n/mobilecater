package com.azhar.catering.load;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import androidx.appcompat.app.AppCompatActivity;

import com.azhar.catering.R;
import com.azhar.catering.login.LoginActivity;
import com.azhar.catering.main.MainActivity;

public class SplashActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_loadpage);

        // Delay 2 seconds to show splash screen
        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                // Cek status login dari SharedPreferences
                SharedPreferences prefs = getSharedPreferences("MyAppPrefs", MODE_PRIVATE);
                boolean isLoggedIn = prefs.getBoolean("isLoggedIn", false);
                Log.d("SplashActivity", "isLoggedIn: " + isLoggedIn);

                // Pindah ke MainActivity atau LoginActivity berdasarkan status login
                Intent intent;
                if (isLoggedIn) {
                    intent = new Intent(SplashActivity.this, MainActivity.class);
                } else {
                    intent = new Intent(SplashActivity.this, LoginActivity.class);
                }
                startActivity(intent);
                finish(); // Menutup SplashActivity agar tidak kembali ke halaman ini
            }
        }, 2000); // 2000ms = 2 detik
    }
}
