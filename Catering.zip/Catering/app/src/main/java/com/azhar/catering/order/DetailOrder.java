package com.azhar.catering.order;

import com.azhar.catering.R;
import com.azhar.catering.history.FeedbackActivity;
import com.azhar.catering.history.HistoryOrderActivity;
import com.azhar.catering.login.LoginActivity;
import com.azhar.catering.main.MainActivity;
import com.azhar.catering.register.RegisterActivity;
import com.azhar.catering.register.RegisterViewModel;
import com.azhar.catering.utils.FunctionHelper;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.widget.Toolbar;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.ViewModelProvider;

import java.text.NumberFormat;
import java.util.Locale;

public class DetailOrder extends AppCompatActivity {

    private static final int REQUEST_MAP_LOCATION = 1;
    private EditText edtAlamatPenerima;
    private RadioGroup rgPengantaran;
    private LinearLayout layoutPesanan;
    private TextView tvTotalHarga, tvOngkir, tvCatatan;
    private Button btnCheckout, btnTambah;
    public String detailPesanan, alamatlokasi;
    private int ongkir;
    private int totalHarga;
    Toolbar toolbar;
    OrderViewModel orderViewModel;

    // Koordinat UNESA Ketintang Surabaya
    private final double unesaLat = -7.314212164520015; // Latitude UNESA Ketintang
    private final double unesaLng = 112.72678547245187; // Longitude UNESA Ketintang

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_order_now);
        setToolbar();

        // Inisialisasi ViewModel
        orderViewModel = new ViewModelProvider(this).get(OrderViewModel.class);

        // Inisialisasi View
        EditText edtAlamatPengirim = findViewById(R.id.edtAlamatPengirim);
        edtAlamatPenerima = findViewById(R.id.edtAlamatPenerima);
        rgPengantaran = findViewById(R.id.rgPengantaran);
        // Menghubungkan Views
        tvTotalHarga = findViewById(R.id.tvTotalHarga);         // ID untuk total harga
        layoutPesanan = findViewById(R.id.layoutPesanan);       // ID untuk layout pesanan yang akan diisi secara dinamis
        btnCheckout = findViewById(R.id.btnCheckout);
        tvOngkir = findViewById(R.id.tvOngkir);
        btnTambah = findViewById(R.id.btnTambah);
        tvCatatan = findViewById(R.id.tvCatatan);

        // Set default alamat pengirim
        edtAlamatPengirim.setText("UNESA Ketintang Surabaya");

        // Optionally, pass the coordinates to MapActivity or store them for further use
        edtAlamatPengirim.setTag(new double[]{unesaLat, unesaLng}); // You can store coordinates as a tag if needed

        // Nonaktifkan EditText alamat penerima secara default
        edtAlamatPenerima.setEnabled(false);

        // Pilihan Pengantaran
        rgPengantaran.setOnCheckedChangeListener((group, checkedId) -> {
            if (checkedId == R.id.rbDelivery) {
                edtAlamatPenerima.setEnabled(true);
            } else if (checkedId == R.id.rbPickUp) {
                edtAlamatPenerima.setEnabled(false);
                edtAlamatPenerima.setText("");  // Kosongkan jika Pick Up
            }
        });

        // Klik alamat penerima untuk memilih lokasi di MapActivity
        edtAlamatPenerima.setOnClickListener(v -> {
            if (edtAlamatPenerima.isEnabled()) {
                Intent intent = new Intent(DetailOrder.this, MapActivity.class);
                startActivityForResult(intent, REQUEST_MAP_LOCATION);
            }
        });

        // Mendapatkan data dari Intent
        Intent intent = getIntent();
        detailPesanan = intent.getStringExtra("DETAIL_PESANAN");
        totalHarga = intent.getIntExtra("TOTAL_HARGA", 0);


// Menampilkan total harga menggunakan format rupiah langsung di sini
        tvTotalHarga.setText("Total: " + formatRupiah(totalHarga));
        // Menampilkan rincian pesanan ke dalam layoutPesanan
        displayOrderDetails(detailPesanan);

        // Klik Checkout
        btnCheckout.setOnClickListener(v -> {
            // Prepare data to insert into Firebase
            String strMenu = detailPesanan;  // detailPesanan already retrieved from intent
            int intHarga = totalHarga;        // totalHarga already retrieved from intent
            // Use the address from the map activity if available
            String strAlamat = alamatlokasi;
            int intOngkir = ongkir;           // Get shipping cost (integer format)
            int intTotal = totalHarga + intOngkir;  // Calculate total price
            String strCatatan = tvCatatan.getText().toString();         // Get notes

            // Call ViewModel to insert data into Firebase
            orderViewModel.addDataOrder(strMenu, intHarga, strAlamat, intTotal, intOngkir, strCatatan);

            Toast.makeText(DetailOrder.this, "Pesanan berhasil dibuat!", Toast.LENGTH_SHORT).show();

            // Start the HistoryOrderActivity after the order is completed
            Intent historyIntent = new Intent(DetailOrder.this, HistoryOrderActivity.class);
            // If you want to pass some data to HistoryOrderActivity, you can use putExtra here
            historyIntent.putExtra("DETAIL_PESANAN", detailPesanan);
            historyIntent.putExtra("ONGKIR", ongkir);// example
            startActivity(historyIntent);  // Start HistoryOrderActivity
        });


        btnTambah.setOnClickListener(v -> {
            // Mengirimkan alamat sebagai hasil kembali
            Intent resultIntent = new Intent();
            intent.putExtra("DETAIL_PESANAN", detailPesanan);
            setResult(RESULT_OK, resultIntent);
            finish();  // Kembali ke DetailOrder setelah memilih lokasi
        });
    }

    // Setup toolbar
    private void setToolbar() {
        toolbar = findViewById(R.id.toolbar);
        toolbar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(DetailOrder.this, MainActivity.class);
                startActivity(intent);
            }
        });
    }


        // Format harga menjadi format Rupiah
    private String formatRupiah(double amount) {
        NumberFormat format = NumberFormat.getCurrencyInstance(new Locale("id", "ID"));
        return format.format(amount);
    }

    // Menampilkan rincian pesanan ke dalam layoutPesanan
    private void displayOrderDetails(String detailPesanan) {
        if (detailPesanan == null || detailPesanan.isEmpty()) {
            TextView tvKosong = new TextView(this);
            tvKosong.setText("Belum ada pesanan");
            layoutPesanan.addView(tvKosong);
            return;
        }

        String[] items = detailPesanan.split("\n");

        for (String item : items) {
            if (!item.isEmpty()) {
                // Buat LinearLayout baru untuk setiap item pesanan
                LinearLayout itemLayout = new LinearLayout(this);
                itemLayout.setLayoutParams(new LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.MATCH_PARENT,
                        LinearLayout.LayoutParams.WRAP_CONTENT
                ));
                itemLayout.setOrientation(LinearLayout.HORIZONTAL);

                // Buat TextView untuk nama paket
                TextView tvNamaPaket = new TextView(this);
                tvNamaPaket.setLayoutParams(new LinearLayout.LayoutParams(
                        0,
                        LinearLayout.LayoutParams.WRAP_CONTENT,
                        0.6f
                ));
                tvNamaPaket.setText(item.split("-")[0].trim());

                // Buat TextView untuk harga
                TextView tvHarga = new TextView(this);
                tvHarga.setLayoutParams(new LinearLayout.LayoutParams(
                        0,
                        LinearLayout.LayoutParams.WRAP_CONTENT,
                        0.4f
                ));
                tvHarga.setGravity(android.view.Gravity.END);
                tvHarga.setText(item.split("-")[1].trim());

                // Tambahkan item pesanan ke layout
                itemLayout.addView(tvNamaPaket);
                itemLayout.addView(tvHarga);
                layoutPesanan.addView(itemLayout);
            }
        }
    }

    // Tangkap hasil lokasi dari MapActivity dan hitung ongkir
    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQUEST_MAP_LOCATION && resultCode == RESULT_OK && data != null) {
            alamatlokasi = data.getStringExtra("ALAMAT_LOKASI");
            edtAlamatPenerima.setText(alamatlokasi);
            // Mendapatkan koordinat penerima dari data
            double penerimaLat = data.getDoubleExtra("LATITUDE", 0);
            double penerimaLng = data.getDoubleExtra("LONGITUDE", 0);

            // Menghitung jarak antara UNESA Ketintang dan alamat penerima
            double distance = calculateDistance(unesaLat, unesaLng, penerimaLat, penerimaLng);

            // Menghitung ongkir berdasarkan jarak
            int ongkir = calculateOngkir(distance);

            // Menampilkan ongkir
            tvOngkir.setText("Ongkir: " + formatRupiah(ongkir));

            // Menampilkan total harga setelah menambahkan ongkir
            tvTotalHarga.setText("Total: " + formatRupiah(totalHarga + ongkir));
        }
    }

    // Menghitung ongkir berdasarkan jarak
    private int calculateOngkir(double distance) {
        int ongkir = 5000; // Ongkir default untuk 1 km pertama
        if (distance > 1) {
            double extraDistance = distance - 1;  // Jarak di atas 1 km
            int additionalOngkir = (int) Math.ceil(extraDistance / 0.3) * 500; // Setiap 300m = 500
            ongkir += additionalOngkir;
        }
        return ongkir;
    }

    // Menghitung jarak antara dua koordinat (latitude, longitude) menggunakan Haversine Formula
    private double calculateDistance(double lat1, double lon1, double lat2, double lon2) {
        final int R = 6371; // Radius bumi dalam km
        double latDistance = Math.toRadians(lat2 - lat1);
        double lonDistance = Math.toRadians(lon2 - lon1);
        double a = Math.sin(latDistance / 2) * Math.sin(latDistance / 2) +
                Math.cos(Math.toRadians(lat1)) * Math.cos(Math.toRadians(lat2)) *
                        Math.sin(lonDistance / 2) * Math.sin(lonDistance / 2);
        double c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
        return c; // Jarak dalam km
    }
}


