package com.azhar.catering.database.dao;

import android.util.Log;

import androidx.annotation.NonNull;
import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;

import com.azhar.catering.database.DatabaseModel;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class DatabaseDao {

    private final FirebaseDatabase firebaseDatabase;

    public DatabaseDao() {
        // Inisialisasi Firebase Database
        firebaseDatabase = FirebaseDatabase.getInstance();
    }

    /**
     * Fungsi untuk mendapatkan semua data dari node "orders"
     */
    public LiveData<List<DatabaseModel>> getAllOrder() {
        MutableLiveData<List<DatabaseModel>> allOrders = new MutableLiveData<>();
        firebaseDatabase.getReference("orders") // Node utama untuk "orders"
                .addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                        List<DatabaseModel> orders = new ArrayList<>();
                        for (DataSnapshot snapshot : dataSnapshot.getChildren()) {
                            DatabaseModel order = snapshot.getValue(DatabaseModel.class);
                            if (order != null) {
                                orders.add(order);
                            }
                        }
                        allOrders.setValue(orders); // Set nilai jika data ditemukan
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError databaseError) {
                        allOrders.setValue(null); // Set null jika terjadi error
                    }
                });
        return allOrders;
    }

    /**
     * Fungsi untuk login berdasarkan username dan password dari node "users"
     */
    public LiveData<DatabaseModel> getUserByName(String username, String password) {
        MutableLiveData<DatabaseModel> userLiveData = new MutableLiveData<>();
        firebaseDatabase.getReference("users") // Node utama untuk "users"
                .addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                        for (DataSnapshot snapshot : dataSnapshot.getChildren()) {
                            DatabaseModel user = snapshot.getValue(DatabaseModel.class);
                            if (user != null && username.equals(user.getUsername()) && password.equals(user.getPassword())) {
                                userLiveData.setValue(user); // Jika ditemukan, set nilainya
                                return;
                            }
                        }
                        userLiveData.setValue(null); // Jika tidak ditemukan, set null
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError databaseError) {
                        userLiveData.setValue(null); // Set null jika terjadi error
                    }
                });
        return userLiveData;
    }

    /**
     * Fungsi untuk menambahkan data baru ke node "users"
     */
    public void insertData(DatabaseModel modelDatabase) {
        String key = firebaseDatabase.getReference("users").push().getKey(); // Buat key baru secara otomatis
        if (key != null) {
            firebaseDatabase.getReference("users").child(key).setValue(modelDatabase)
                    .addOnSuccessListener(aVoid -> Log.d("Firebase", "Data berhasil ditambahkan."))
                    .addOnFailureListener(e -> Log.e("Firebase", "Gagal menambahkan data.", e));
        }
    }

    /**
     * Fungsi untuk memperbarui data pada node "orders"
     */
    public void updateData(String uid, String nama_menu, int jml_items, int harga) {
        Map<String, Object> updates = new HashMap<>();
        updates.put("nama_menu", nama_menu);
        updates.put("jml_items", jml_items);
        updates.put("harga", harga);

        firebaseDatabase.getReference("orders").child(uid).updateChildren(updates)
                .addOnSuccessListener(aVoid -> Log.d("Firebase", "Data berhasil diperbarui."))
                .addOnFailureListener(e -> Log.e("Firebase", "Gagal memperbarui data.", e));
    }

    /**
     * Fungsi untuk menghapus data pada node "orders" berdasarkan UID
     */
    public void deleteSingleData(String uid) {
        firebaseDatabase.getReference("orders").child(uid).removeValue()
                .addOnSuccessListener(aVoid -> Log.d("Firebase", "Data berhasil dihapus."))
                .addOnFailureListener(e -> Log.e("Firebase", "Gagal menghapus data.", e));
    }
}
