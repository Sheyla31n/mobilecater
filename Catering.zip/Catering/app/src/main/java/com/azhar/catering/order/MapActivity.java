package com.azhar.catering.order;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.ViewModelProvider;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.location.Address;
import android.location.Geocoder;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Toast;

import com.azhar.catering.R;
import com.azhar.catering.register.RegisterViewModel;
import com.mapbox.api.geocoding.v5.MapboxGeocoding;
import com.mapbox.api.geocoding.v5.models.CarmenFeature;
import com.mapbox.geojson.Point;
import com.mapbox.mapboxsdk.Mapbox;
import com.mapbox.mapboxsdk.annotations.MarkerOptions;
import com.mapbox.mapboxsdk.camera.CameraUpdateFactory;
import com.mapbox.mapboxsdk.geometry.LatLng;
import com.mapbox.mapboxsdk.maps.MapboxMap;
import com.mapbox.mapboxsdk.maps.OnMapReadyCallback;
import com.mapbox.mapboxsdk.maps.Style;
import com.mapbox.mapboxsdk.maps.MapView;

import java.io.IOException;
import java.util.List;
import java.util.Locale;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class MapActivity extends AppCompatActivity {

    private MapView mapView;
    private MapboxMap mapboxMap;
    private EditText searchBar;
    private ImageButton searchButton;
    private Button btnOk;
    private Button btnCancel;
    private LatLng selectedLocation; // Tambahkan deklarasi ini
    OrderViewModel orderViewModel;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Inisialisasi Mapbox
        Mapbox.getInstance(this, getString(R.string.mapbox_access_token));
        setContentView(R.layout.activity_map);

        // Inisialisasi View
        mapView = findViewById(R.id.mapView);
        searchBar = findViewById(R.id.searchAddress);  // Sesuai ID dari layout
        searchButton = findViewById(R.id.btnSearch);
        btnOk = findViewById(R.id.btnOk);
        btnCancel = findViewById(R.id.btnCancel);

        // Inisialisasi ViewModel
        orderViewModel = new ViewModelProvider(this).get(OrderViewModel.class);

        // Inisialisasi MapView
        mapView.onCreate(savedInstanceState);
        mapView.getMapAsync(new OnMapReadyCallback() {
            @Override
            public void onMapReady(@NonNull MapboxMap mapboxMap) {
                MapActivity.this.mapboxMap = mapboxMap;

                mapboxMap.setStyle(Style.MAPBOX_STREETS, new Style.OnStyleLoaded() {
                    @Override
                    public void onStyleLoaded(@NonNull Style style) {
                        // Lokasi awal di Surabaya, Ketintang
                        LatLng initialLocation = new LatLng(-7.2966, 112.7341);
                        mapboxMap.animateCamera(CameraUpdateFactory.newLatLngZoom(initialLocation, 14));

                        if (mapboxMap != null) {
                            mapboxMap.addOnMapClickListener(point -> {
                                selectedLocation = new LatLng(point.getLatitude(), point.getLongitude());

                                // Add marker at selected location
                                addMarker(selectedLocation);

                                return true;
                            });
                        }

                        Toast.makeText(MapActivity.this, "Peta berhasil dimuat!", Toast.LENGTH_SHORT).show();
                    }
                });

                // Set Zoom Controls (Manual)
                findViewById(R.id.btnZoomIn).setOnClickListener(v -> {
                    if (mapboxMap != null) {
                        mapboxMap.animateCamera(CameraUpdateFactory.zoomIn());
                    }
                });

                findViewById(R.id.btnZoomOut).setOnClickListener(v -> {
                    if (mapboxMap != null) {
                        mapboxMap.animateCamera(CameraUpdateFactory.zoomOut());
                    }
                });
            }
        });

        // Set Listener untuk Search Button
        searchButton.setOnClickListener(v -> {
            String query = searchBar.getText().toString().trim();
            if (!query.isEmpty()) {
                searchLocation(query); // Panggil fungsi pencarian
            } else {
                Toast.makeText(MapActivity.this, "Masukkan lokasi untuk mencari.", Toast.LENGTH_SHORT).show();
            }
        });

        btnOk.setOnClickListener(v -> {
            if (selectedLocation != null) {
                double latitude = selectedLocation.getLatitude();
                double longitude = selectedLocation.getLongitude();

                // Menggunakan Geocoder untuk mengonversi latitude dan longitude ke alamat
                Geocoder geocoder = new Geocoder(MapActivity.this, Locale.getDefault());
                try {
                    List<Address> addresses = geocoder.getFromLocation(latitude, longitude, 1);
                    if (addresses != null && !addresses.isEmpty()) {
                        Address address = addresses.get(0);
                        String alamat = address.getAddressLine(0);  // Mendapatkan alamat pertama

                        // Mengirimkan alamat sebagai hasil kembali
                        Intent resultIntent = new Intent();
                        resultIntent.putExtra("ALAMAT_LOKASI", alamat);
                        setResult(RESULT_OK, resultIntent);
                        finish();  // Kembali ke DetailOrder setelah memilih lokasi
                    } else {
                        Toast.makeText(MapActivity.this, "Alamat tidak ditemukan.", Toast.LENGTH_SHORT).show();
                    }
                } catch (IOException e) {
                    e.printStackTrace();
                    Toast.makeText(MapActivity.this, "Gagal mengonversi koordinat ke alamat.", Toast.LENGTH_SHORT).show();
                }
            } else {
                Toast.makeText(MapActivity.this, "Pilih lokasi terlebih dahulu.", Toast.LENGTH_SHORT).show();
            }
        });


        btnCancel.setOnClickListener(v -> {
            Intent intent = new Intent(MapActivity.this, DetailOrder.class);
            startActivity(intent);
        });
    }

    private void addMarker(LatLng location) {
        if (mapboxMap != null) {
            mapboxMap.clear();
        }

        Bitmap icon = BitmapFactory.decodeResource(getResources(), R.drawable.ic_location);
        mapboxMap.addMarker(new MarkerOptions()
                .position(location)  // Fix penggunaan initialLocation -> location
                .title("Lokasi Anda"));
    }

    private void searchLocation(String query) {
        MapboxGeocoding geocoding = MapboxGeocoding.builder()
                .accessToken(getString(R.string.mapbox_access_token))
                .query(query)
                .build();

        geocoding.enqueueCall(new Callback<com.mapbox.api.geocoding.v5.models.GeocodingResponse>() {
            @Override
            public void onResponse(@NonNull Call<com.mapbox.api.geocoding.v5.models.GeocodingResponse> call,
                                   @NonNull Response<com.mapbox.api.geocoding.v5.models.GeocodingResponse> response) {
                if (response.isSuccessful() && response.body() != null) {
                    List<CarmenFeature> features = response.body().features();
                    if (!features.isEmpty()) {
                        CarmenFeature feature = features.get(0);
                        Point location = feature.center();

                        if (location != null) {
                            double latitude = location.latitude();
                            double longitude = location.longitude();
                            LatLng latLng = new LatLng(latitude, longitude);
                            mapboxMap.animateCamera(CameraUpdateFactory.newLatLngZoom(latLng, 14));

                            addMarker(latLng);

                            Toast.makeText(MapActivity.this, "Lokasi ditemukan: " + feature.placeName(), Toast.LENGTH_SHORT).show();
                        }
                    }
                }
            }
            @Override
            public void onFailure(@NonNull Call<com.mapbox.api.geocoding.v5.models.GeocodingResponse> call,
                                  @NonNull Throwable t) {
                Toast.makeText(MapActivity.this, "Terjadi kesalahan: " + t.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }
}
